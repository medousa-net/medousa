package medousa.test;

import java.net.HttpURLConnection;
import java.net.URL;

public class CheckURLConnectivity {
    public static void main(String[] args) {
        boolean urlOk = false;
        try {
            URL url = new URL("https://github.com/ds-chkang/cdfdfdfi");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("HEAD");
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                urlOk = true;
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            if (urlOk) {
                System.out.println("URL is connectable.");
            } else {
                System.out.println("URL is not connectable.");
            }
        }
    }
}