package medousa.direct.broker;

//import datamining.spm.topology.view.successorViewer.*;

public class MyDirectGraphTopologyBroker
extends MyDirectGraphViewerBroker {

    public MyDirectGraphTopologyBroker() throws Exception {
        super();
    }

}
