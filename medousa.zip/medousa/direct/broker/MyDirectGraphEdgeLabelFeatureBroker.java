package medousa.direct.broker;

public class MyDirectGraphEdgeLabelFeatureBroker
extends MyDirectGraphEdgeValueFeatureBroker {
    public MyDirectGraphEdgeLabelFeatureBroker() { super(); }
}