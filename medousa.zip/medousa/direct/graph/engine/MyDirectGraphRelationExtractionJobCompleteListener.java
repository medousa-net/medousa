package medousa.direct.graph.engine;

public interface MyDirectGraphRelationExtractionJobCompleteListener {
    public void startNextPrefixer(final Thread prefixer);
}
