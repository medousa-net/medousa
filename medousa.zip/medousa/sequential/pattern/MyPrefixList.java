package medousa.sequential.pattern;

import java.util.HashMap;

public class MyPrefixList
extends HashMap<String, MyPrefix> {

    public MyPrefixList() {}

}