package medousa.sequential.pattern;

public interface MyPrefixerCompleteListener {
    public void startNextPrefixer(final Thread prefixer);
}
