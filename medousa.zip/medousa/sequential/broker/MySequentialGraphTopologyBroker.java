package medousa.sequential.broker;

//import medousa.sequential.datamining.spm.topology.view.successorViewer.*;

public class MySequentialGraphTopologyBroker
extends MySequentialGraphViewerBroker {

    public MySequentialGraphTopologyBroker() throws Exception {
        super();
    }

}
