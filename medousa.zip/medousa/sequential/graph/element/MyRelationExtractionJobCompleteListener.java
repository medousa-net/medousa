package medousa.sequential.graph.element;

public interface MyRelationExtractionJobCompleteListener {
    public void startNextPrefixer(final Thread prefixer);
}
