package medousa.sequential.graph.funnel;

import medousa.sequential.graph.layout.MyDirectedSparseMultigraph;

import java.io.Serializable;

public class MyFunnelGraph<V, E>
extends MyDirectedSparseMultigraph<V, E>
implements Serializable {
}
